<hr style="color: #000; background: #bbb; height: 1px;" />
<div class="tabothers">
 
    <div class="threeothers" id="itemThree_<?php print_r($item->itemid); ?>" data-userid="<?php print_r($item->userid); ?>"></div>
    <div id="wishtradeMSG_<?php print_r($item->itemid); ?>"></div>
</div>
<div style="clear: both;"></div>
 <div id="itemid_<?php echo $item->id;?>" data-requestsNUM='564'>
   <div style="clear: both;"></div>      
    </div>

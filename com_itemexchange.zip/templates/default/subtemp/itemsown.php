<hr style="color: #000; background: #bbb; height: 1px;" />
    <p class='aitemrequests' id='itemidClass_<?php echo $item->id;?>'>
        <a class='aitemrequests' href='javascript:void(0)'>Number of requests: <?php echo $item->is_requested; ?></a></p>
   
    <div id="itemid_<?php echo $item->id;?>" data-requests='564'>dddd
        
    </div>